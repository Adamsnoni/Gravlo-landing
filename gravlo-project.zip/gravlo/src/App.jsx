import LandingPage from './LandingPage.jsx'

export default function App() {
  return <LandingPage />
}
